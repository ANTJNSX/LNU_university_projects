
change.py:
	I detta program tar jag en input som ett heltal och rundar priset korrekt, sedan loopar jag igenom ett långt if else block
	som man kan ta bort en stor mängd ifrån de. Scripten går från högst värde neråt så att den alltid tar bort den största mängden
	den kan. När värdet når 0 så bryter den sig ut ur while loopen och printar ut resultaten.

sum_of_three.py:
	Jag tar deras input som en string och sen tar jag varje index för karaktärerna för att konvertera de in till heltal och lägger ihop dom.
	Man kunde även ha tagit inputen som ett heltal och sedan tagit modulus för att extrahera varje värde. 

Squarecolor.py:
	Så här tog jag inputen av en schack koordinat och bryter den i 2 delar, en karaktär och en int. karaktären som är en liten bokstav kan
	konverteras till ett ascii värde som kan kollas ifall det är jämnt eller udda, sen tas den andra heltalet och kollar ifall den är udda.
	Sen kollas ifall båda talen är udda eller jämna för att sen bestämma om det betyder att de är en vit eller svart ruta.

taxes.py:
	Man börjar med att ta en input för månads inkomsten, sedan skapar vi en variabel för den minsta skatten man betalar. efter det beräknas din
	skatt beroende på hur mycket du tjänar. Ju mer du tjänar så behöver du beräkna de tidigare skatterna du skulle betala, samt de nya.
