n = input("Provide a three digit number: ")


s = int(n[0])+int(n[1])+int(n[2])

print("Sum of digits:",s)
